﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace txtfilelogin
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string hash = BCrypt.Net.BCrypt.HashPassword(textBox2.Text);
            if(File.Exists("login.txt"))
            {
                File.AppendAllText("login.txt", "\n" + textBox1.Text + "," + hash);

            }
            else
            {
                File.Create("login.txt").Dispose();
                File.WriteAllText("login.txt", textBox1.Text + "," + hash);
            }
            MessageBox.Show("Sucessfully recorded");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int record = 1;
            foreach(string s in File.ReadAllLines("login.txt"))
            {
                if(s.Split(",")[0]==textBox1.Text)
                {
                    bool verify = BCrypt.Net.BCrypt.Verify(textBox2.Text, s.Split(",")[1]);
                    if(verify)
                    {
                        MessageBox.Show("The record is at " + record.ToString());
                    }
                }
                record = record + 1;
            }
        }
    }
}
